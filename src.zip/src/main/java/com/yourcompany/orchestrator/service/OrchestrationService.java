package com.yourcompany.orchestrator.service;

import org.springframework.stereotype.Service;

import com.yourcompany.orchestrator.analyzer.PromptAnalyzer;
import com.yourcompany.orchestrator.core.AIResponse;
import com.yourcompany.orchestrator.core.ModelRule;
import com.yourcompany.orchestrator.core.TaskType;
import com.yourcompany.orchestrator.routing.ModelRouter;

@Service
public class OrchestrationService {

    private final PromptAnalyzer analyzer;
    private final RuleEngine ruleEngine;
    private final ModelRouter router;

    public OrchestrationService(PromptAnalyzer analyzer,
                                RuleEngine ruleEngine,
                                ModelRouter router) {
        this.analyzer = analyzer;
        this.ruleEngine = ruleEngine;
        this.router = router;
    }

    public AIResponse process(String prompt) {

        TaskType task = analyzer.analyze(prompt);

        ModelRule rule = ruleEngine.resolve(task);

        return router.route(
                rule.getProviderName(),
                rule.getModelName(),
                prompt
        );
    }
}