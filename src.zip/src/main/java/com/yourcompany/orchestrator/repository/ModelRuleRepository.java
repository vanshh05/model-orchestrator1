package com.yourcompany.orchestrator.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yourcompany.orchestrator.core.ModelRule;
import com.yourcompany.orchestrator.core.TaskType;

public interface ModelRuleRepository
        extends JpaRepository<ModelRule, Long> {

    Optional<ModelRule>
    findFirstByTaskTypeAndActiveTrueOrderByPriorityAsc(TaskType taskType);
}