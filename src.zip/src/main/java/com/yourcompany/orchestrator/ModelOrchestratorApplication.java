package com.yourcompany.orchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelOrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(ModelOrchestratorApplication.class, args);
    }
}
