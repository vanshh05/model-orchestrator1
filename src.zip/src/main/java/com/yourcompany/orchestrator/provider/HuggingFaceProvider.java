package com.yourcompany.orchestrator.provider;
import com.yourcompany.orchestrator.core.AIRequest;
import com.yourcompany.orchestrator.core.AIResponse;

public class HuggingFaceProvider implements AIProvider {

    @Override
    public String getName() {
        return "huggingface";
    }

    @Override
    public AIResponse generate(AIRequest request) {

        return new AIResponse(
                "Mock response from HuggingFace for model: "
                        + request.getModelName(),
                "huggingface",
                request.getModelName()
        );
    }
}