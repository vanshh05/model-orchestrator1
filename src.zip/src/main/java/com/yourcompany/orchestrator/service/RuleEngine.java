package com.yourcompany.orchestrator.service;

import org.springframework.stereotype.Service;
import com.yourcompany.orchestrator.repository.ModelRuleRepository;
import com.yourcompany.orchestrator.core.ModelRule;
import com.yourcompany.orchestrator.core.TaskType;

@Service
public class RuleEngine {

    private final ModelRuleRepository repository;

    public RuleEngine(ModelRuleRepository repository) {
        this.repository = repository;
    }

    public ModelRule resolve(TaskType taskType) {
        return repository
                .findFirstByTaskTypeAndActiveTrueOrderByPriorityAsc(taskType)
                .orElseThrow(() ->
                        new RuntimeException("No rule found for task: " + taskType));
    }
}