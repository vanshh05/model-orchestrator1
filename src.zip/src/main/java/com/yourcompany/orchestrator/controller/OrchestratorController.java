package com.yourcompany.orchestrator.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yourcompany.orchestrator.core.AIResponse;
import com.yourcompany.orchestrator.service.OrchestrationService;

@RestController
@RequestMapping("/api/v1/orchestrator")
public class OrchestratorController {

    private final OrchestrationService service;

    public OrchestratorController(OrchestrationService service) {
        this.service = service;
    }

    @PostMapping("/process")
    public AIResponse process(@RequestBody String prompt) {
        return service.process(prompt);
    }
}