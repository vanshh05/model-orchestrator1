package com.yourcompany.orchestrator.analyzer;

import org.springframework.stereotype.Component;
import com.yourcompany.orchestrator.core.TaskType;

@Component
public class PromptAnalyzer {

    public TaskType analyze(String prompt) {
        String p = prompt.toLowerCase();

        if (p.contains("code") || p.contains("java"))
            return TaskType.CODE;

        if (p.contains("video") || p.contains("animation"))
            return TaskType.VIDEO;

        if (p.contains("image") || p.contains("logo"))
            return TaskType.IMAGE;

        return TaskType.GENERAL_CHAT;
    }
}
